from django.shortcuts import render
import datetime

# Create your views here.
def index(request):
    now = datetime.datetime.now()
    if now.month == 6 and now.day == 21:
        name = "Aanya"
    elif now.month == 8 and now.day == 25:
        name = "Aaryan"
    elif now.month == 11 and now.day == 5:
        name = "Abhinav"
    elif now.month == 10 and now.day == 19:
        name = "Abhiviraj"
    elif now.month == 9 and now.day == 7:
        name = "Aditya"
    elif now.month == 4 and now.day == 3:
        name = "Aiyana"
    elif now.month == 12 and now.day == 6:
        name = "Anamika"
    elif now.month == 8 and now.day == 17:
        name = "Aneesh"
    elif now.month == 10 and now.day == 24:
        name = "Anishka"
    elif now.month == 12 and now.day == 22:
        name = "Arhaan"
    elif now.month == 6 and now.day == 17:
        name = "Arhan"
    elif now.month == 1 and now.day == 21:
        name = "Dev"
    elif now.month == 2 and now.day == 6:
        name = "Dhrriti"
    elif now.month == 10 and now.day == 10:
        name = "Divya"
    elif now.month == 12 and now.day == 21:
        name = "Elisha"
    elif now.month == 11 and now.day == 6:
        name = "Falak"
    elif now.month == 10 and now.day == 25:
        name = "Hrishita"
    elif now.month == 10 and now.day == 17:
        name = "Iman"
    elif now.month == 1 and now.day == 14:
        name = "Keren"
    elif now.month == 12 and now.day == 10:
        name = "Niharika"
    elif now.month == 8 and now.day == 2:
        name = "Nikita"
    elif now.month == 11 and now.day == 16:
        name = "Prisha"
    elif now.month == 8 and now.day == 27:
        name = "Reya, Vansh and Vivaan"
    elif now.month == 12 and now.day == 14:
        name = "Vahrun"
    elif now.month == 8 and now.day == 31:
        name = "Zahra"
    elif now.month == 10 and now.day == 7:
        name = "Yashraj"
    elif now.month == 2 and now.day == 16:
        name = "Veer"
    elif now.month == 3 and now.day == 9:
        name = "Rhea"
    elif now.month == 3 and now.day == 11:
        name = "Durga"                                            

    else:
        birthday = False
        name = "NO"
    return render(request, "class9b/index.html", {
        "bday":name
    })