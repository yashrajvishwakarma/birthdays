from django.apps import AppConfig


class Class9BConfig(AppConfig):
    name = 'class9b'
